package com.CypherLand.EncryptionData;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EncryptionDataApplication {

	public static void main(String[] args) {
		SpringApplication.run(EncryptionDataApplication.class, args);
	}

}
